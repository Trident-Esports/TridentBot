# VillainsBot

* Install [Node.js](https://nodejs.org/en/)
* Update NPM: `npm update`
* Install Dependencies: `npm install`
* Run `node .`
