module.exports = {
    name: 'discord',
    description: "This is to join the bot discord server",
    execute(message, args, cmd, client) {
        message.channel.send('https://discord.gg/Gh2Jh5FpVS');
    }
}