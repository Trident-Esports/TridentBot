module.exports = {
    name: 'upupdowndownleftrightleftrightbastart',
    description: "This is an Easter Egg",
    execute(message, args, cmd, client) {
        message.channel.send('You must be on a windows computer for this to work.');
        message.channel.send('https://itsmattkc.com/etc/snakeqr/code.png')
    }
}