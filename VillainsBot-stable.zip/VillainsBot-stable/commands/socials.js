module.exports = {
    name: 'socials',
    aliases: ['instagram', 'twitch', 'facebook', 'twitter'], 
    description: "This is a socials link",
    execute(message, args, cmd, client) {
        message.channel.send('https://linktr.ee/Villainsesc');
    }
}