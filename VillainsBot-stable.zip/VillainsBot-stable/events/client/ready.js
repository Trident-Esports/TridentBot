module.exports = () => {

    console.log('VillainsBot is Online!');
}