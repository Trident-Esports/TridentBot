
module.exports = {
    name: 'test',
    aliases: ['t'],
    permissions: [],
    description: "testing",
    execute(client){

       console.log('Made it here');
       
    }
};