module.exports = [
    {
        item: 'car',
        price: '20000',
    },
    {
        item: 'bananas',
        price: '50',
    },
    {
        item: 'lottery ticket',
        price: '200',
    },
];
